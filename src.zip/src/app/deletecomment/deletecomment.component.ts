import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletecomment',
  templateUrl: './deletecomment.component.html',
  styleUrls: ['./deletecomment.component.css']
})
export class DeletecommentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
