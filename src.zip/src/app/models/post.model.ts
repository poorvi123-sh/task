export interface AddPost{
    productid:number;
    name:string,
    desc:string;
    price:string;
    photo:string;

}