export interface Myblog{
   
    title:string,
    name:string,
    address:string

}