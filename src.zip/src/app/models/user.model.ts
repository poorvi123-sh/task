export interface User{
    id?:number;
    name:string;
    contact:number;
     age:number;
     email:string;
     password:string;
     city:string;
    photo:string;
}